# ===================== 冒烟测试 =====================
# v5-R0：给重构建立基线。
# 运行：python -m unittest discover -s tests -v
#
# 约定：
#   - 标了 @unittest.expectedFailure 的用例，记录的是「已知 bug 的当前行为」。
#     修好之后去掉装饰器，它就会变成守护用例。
#   - 本机缺 pymysql / jieba / aiohttp / PIL 时自动打桩；装了真依赖则不打桩。

import asyncio
import sys
import types
import unittest

# Windows 控制台默认 GBK，日志里有 emoji，统一成 UTF-8
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")
    except Exception:
        pass


def _stub_missing_deps():
    """只在依赖真的缺失时打桩，避免污染真实环境"""
    def module(name, **attrs):
        m = types.ModuleType(name)
        for k, v in attrs.items():
            setattr(m, k, v)
        sys.modules[name] = m
        return m

    try:
        import pymysql  # noqa: F401
    except ImportError:
        module("pymysql")
        module("pymysql.cursors", DictCursor=object)
        sys.modules["pymysql"].cursors = sys.modules["pymysql.cursors"]
        sys.modules["pymysql"].connect = lambda **kw: None

    try:
        import jieba  # noqa: F401
    except ImportError:
        module("jieba", lcut=lambda s: list(s))

    try:
        import aiohttp  # noqa: F401
    except ImportError:
        module("aiohttp")

    try:
        from PIL import Image  # noqa: F401
    except ImportError:
        module("PIL", Image=None)


_stub_missing_deps()

from botv.core import state as cfg             # noqa: E402  运行时状态（常量也在里面）
import botv.commands as commands               # noqa: E402
import botv.chat.reply as reply_mod            # noqa: E402
from botv.ai.parse import parse_ai_reply       # noqa: E402
from botv.cmd import registry                  # noqa: E402


class FakeWS:
    """假的 WebSocket，只记录发出去的内容"""

    def __init__(self):
        self.sent = []

    async def send(self, payload):
        self.sent.append(payload)

    def texts(self):
        """把发出去的 JSON 里的文本抽出来"""
        import json
        out = []
        for raw in self.sent:
            d = json.loads(raw)
            for seg in d["params"]["message"]:
                if seg.get("type") == "text":
                    out.append(seg["data"]["text"])
        return out


class TestParse(unittest.TestCase):
    """AI 回复解析"""

    def test_five_lines(self):
        ans = "你好\n（歪头）\n关键词搜索图片用：猫,狗\n事件摘要：测试 | 标签：a,b\n关键词提炼：a,b"
        dialog, action, img_kw, event, refined = parse_ai_reply(ans)
        self.assertEqual(dialog, "你好")
        self.assertEqual(action, "（歪头）")
        self.assertEqual(img_kw, ["猫", "狗"])
        self.assertEqual(event, "测试")
        self.assertEqual(refined, ["a", "b"])

    def test_single_line(self):
        dialog, action, img_kw, event, refined = parse_ai_reply("只有一句话")
        self.assertEqual(dialog, "只有一句话")
        self.assertEqual(action, "")
        self.assertEqual(img_kw, [])

    def test_none_action(self):
        _, action, _, _, _ = parse_ai_reply("嗯\n（无）")
        self.assertEqual(action, "")

    def test_empty_input(self):
        self.assertEqual(parse_ai_reply(None), ("嗯嗯", "", [], "", []))


class TestReplyAssembly(unittest.TestCase):
    """回复组装：当前行为快照"""

    def setUp(self):
        cfg.CODE_MODE = False
        # 图片搜索依赖数据库，测试里直接短路
        self._orig_get_best_image = reply_mod.get_best_image

        async def _no_image(*args, **kwargs):
            return None

        reply_mod.get_best_image = _no_image

    def tearDown(self):
        reply_mod.get_best_image = self._orig_get_best_image

    def _build(self, text):
        parts = asyncio.run(reply_mod.build_reply_message(text, "10001"))
        return [seg[0]["data"]["text"] for kind, seg in parts if kind == "text"]

    def test_first_two_lines_sent(self):
        texts = self._build("第一句\n（笑）")
        self.assertEqual(texts, ["第一句", "（笑）"])

    def test_multiline_dialog_one_bubble_per_line(self):
        """v6-A12：一行一个气泡，行数由模型决定"""
        texts = self._build("第一句\n第二句\n第三句")
        self.assertEqual(texts, ["第一句", "第二句", "第三句"])

    def test_too_many_lines_merged(self):
        """异常保护：只有超过 10 行才合并尾部"""
        text = "\n".join(f"第{i}行" for i in range(1, 16))
        texts = self._build(text)
        self.assertEqual(len(texts), 10)
        self.assertIn("第15行", texts[-1])

    def test_no_action_sends_no_bubble(self):
        """F1：无动作时不该补一条「（无）」"""
        texts = self._build("只有对话")
        self.assertEqual(texts, ["只有对话"])

    def test_meta_lines_not_sent(self):
        """元数据按标记识别，不进对话"""
        texts = self._build("正文\n关键词搜索图片用：猫\n事件摘要：x\n关键词提炼：a")
        self.assertEqual(texts, ["正文"])

    def test_code_mode_single_message(self):
        """F3：代码模式整段发一条，代码块不被拆散"""
        cfg.CODE_MODE = True
        texts = self._build("答案开头\n```python\nprint(1)\n```\n答案结尾")
        self.assertEqual(len(texts), 1)
        self.assertIn("print(1)", texts[0])
        self.assertIn("答案结尾", texts[0])


class TestCommandRegistry(unittest.TestCase):
    """命令注册表与分发"""

    EXPECTED = {
        "acg", "apikeys", "clear", "clip", "code", "db", "diary", "event",
        "exit", "help", "img", "keywords", "log", "memory", "ping", "quit",
        "reload", "say", "sayg", "set", "status", "sticker", "task",
        "uptime", "usage",
    }

    def setUp(self):
        cfg.CODE_MODE = False

    def _run(self, text, uid=None):
        ws = FakeWS()
        uid = uid if uid is not None else str(cfg.MASTER_QQ)
        handled = asyncio.run(commands.handle_command(text, uid, ws, False, 0))
        return handled, ws

    def test_all_commands_registered(self):
        self.assertEqual(set(registry.COMMANDS), self.EXPECTED)

    def test_help(self):
        handled, ws = self._run("!help")
        self.assertTrue(handled)
        self.assertIn("可用命令", ws.texts()[0])

    def test_ping(self):
        handled, ws = self._run("!ping")
        self.assertTrue(handled)
        self.assertIn("Pong", ws.texts()[0])

    def test_status(self):
        handled, ws = self._run("!status")
        self.assertIn("状态概览", ws.texts()[0])

    def test_unknown_command(self):
        handled, ws = self._run("!nope")
        self.assertTrue(handled)
        self.assertIn("未知命令", ws.texts()[0])

    def test_non_master_ignored(self):
        handled, ws = self._run("!help", uid="123456")
        self.assertFalse(handled)
        self.assertEqual(ws.sent, [])

    def test_non_command_ignored(self):
        handled, ws = self._run("你好呀")
        self.assertFalse(handled)
        self.assertEqual(ws.sent, [])


class TestStructure(unittest.TestCase):
    """结构约定：迁移后这些东西必须还在原位"""

    def test_api_shim_reexports_same_objects(self):
        import botv.api as api
        import botv.ai.client as client
        self.assertIs(api.get_character_reply, client.get_character_reply)
        self.assertIs(api.call_deepseek, client.call_deepseek)

    def test_send_reexports_build_reply(self):
        import botv.send as send
        self.assertIs(send.build_reply_message, reply_mod.build_reply_message)

    def test_http_session_factory(self):
        from botv.core.http import create_http_session
        import requests
        session = create_http_session()
        self.assertIsInstance(session, requests.Session)
        session.close()


class TestFallback(unittest.TestCase):
    """F2：兜底文案不得入库、不得污染关键词"""

    def test_fallback_is_str(self):
        from botv.core.types import Fallback
        f = Fallback("哼")
        self.assertIsInstance(f, str)
        self.assertEqual(f, "哼")

    def test_get_character_reply_marks_fallback(self):
        import botv.ai.client as client
        import botv.memory as mem
        from botv.core.types import Fallback

        async def no_ds(*a, **k):
            return None

        async def fb_doubao(*a, **k):
            return Fallback("哼(扭头)")

        orig_ds, orig_db = client.call_deepseek, client.call_doubao
        orig_ev = mem.load_events_from_db
        client.call_deepseek, client.call_doubao = no_ds, fb_doubao
        mem.load_events_from_db = lambda *a, **k: []  # 测试环境不连库
        try:
            r = asyncio.run(client.get_character_reply("hi", "1"))
        finally:
            client.call_deepseek, client.call_doubao = orig_ds, orig_db
            mem.load_events_from_db = orig_ev
        self.assertIsInstance(r, Fallback)

    def test_add_memory_skips_fallback(self):
        import botv.memory as mem
        from botv.core.types import Fallback

        calls = []
        orig = mem.add_user_memory_to_db
        orig_kw = mem.add_global_keywords_to_db
        mem.add_user_memory_to_db = lambda *a, **k: calls.append(a)
        mem.add_global_keywords_to_db = lambda *a, **k: None  # 测试环境不连库
        try:
            mem.add_target_memory("1", "hi", Fallback("哼"))
            mem.add_target_memory("1", "hi", "正常回复")
        finally:
            mem.add_user_memory_to_db = orig
            mem.add_global_keywords_to_db = orig_kw
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0][2], "正常回复")


class TestImagePath(unittest.TestCase):
    """F4：图片路径解析不依赖当前工作目录"""

    def test_empty(self):
        from botv.utils import resolve_image_path
        self.assertIsNone(resolve_image_path(""))
        self.assertIsNone(resolve_image_path(None))

    def test_relative_resolved_from_project_root(self):
        import os
        from botv.utils import resolve_image_path
        p = resolve_image_path("README.md")  # 项目根下确定存在的文件
        self.assertIsNotNone(p)
        self.assertTrue(os.path.isabs(p))
        self.assertTrue(os.path.exists(p))

    def test_missing_returns_none(self):
        from botv.utils import resolve_image_path
        self.assertIsNone(resolve_image_path("no/such/file.jpg"))

    def test_absolute_existing(self):
        import os
        from botv.utils import resolve_image_path
        p = resolve_image_path(os.path.abspath("README.md"))
        self.assertIsNotNone(p)


class TestOnlineNotice(unittest.TestCase):
    """F5：重连时上线通知不能重复刷"""

    def setUp(self):
        cfg.last_online_notice_ts = 0.0

    def tearDown(self):
        cfg.last_online_notice_ts = 0.0

    def test_first_call_claims(self):
        from botv.chat.handler import claim_online_notice
        self.assertTrue(claim_online_notice())

    def test_second_call_blocked(self):
        from botv.chat.handler import claim_online_notice
        self.assertTrue(claim_online_notice())
        self.assertFalse(claim_online_notice())

    def test_after_cooldown_allowed(self):
        from botv.chat.handler import claim_online_notice
        self.assertTrue(claim_online_notice())
        cfg.last_online_notice_ts -= 61  # 模拟 61 秒前
        self.assertTrue(claim_online_notice())


class TestTimePerception(unittest.TestCase):
    """F7：prompt 里必须带当前时间"""

    def setUp(self):
        cfg.CODE_MODE = False

    def test_now_text_format(self):
        from datetime import datetime
        from botv.ai.prompt import now_text
        from botv.config import CST
        s = now_text(datetime(2026, 11, 8, 23, 30, tzinfo=CST))
        self.assertIn("2026年11月8日", s)
        self.assertIn("23:30", s)
        self.assertIn("深夜", s)

    def test_morning_period(self):
        from datetime import datetime
        from botv.ai.prompt import now_text
        from botv.config import CST
        s = now_text(datetime(2026, 11, 9, 7, 15, tzinfo=CST))
        self.assertIn("早上", s)

    def test_prompt_contains_now(self):
        import botv.ai.client as client
        import botv.memory as mem

        captured = {}

        async def fake_ds(msgs, max_tokens=None, target_id=None):
            captured["sys"] = msgs[0]["content"]
            return "好"

        orig_ds, orig_ev = client.call_deepseek, mem.load_events_from_db
        client.call_deepseek = fake_ds
        mem.load_events_from_db = lambda *a, **k: []
        try:
            asyncio.run(client.get_character_reply("hi", "1"))
        finally:
            client.call_deepseek = orig_ds
            mem.load_events_from_db = orig_ev

        self.assertIn("现在的时间", captured["sys"])
        self.assertNotIn("{now}", captured["sys"])
        self.assertRegex(captured["sys"], r"\d{4}年\d{1,2}月\d{1,2}日 周")


class TestOutbox(unittest.TestCase):
    """F6：断线期间的消息入队，重连后补发"""

    def setUp(self):
        cfg.pending_outbox.clear()

    def tearDown(self):
        cfg.pending_outbox.clear()

    def test_queue_when_disconnected(self):
        from botv.chat.send import send_private_msg
        ok = asyncio.run(send_private_msg(123, [{"type": "text", "data": {"text": "hi"}}], None))
        self.assertFalse(ok)
        self.assertEqual(len(cfg.pending_outbox), 1)

    def test_flush_after_reconnect(self):
        from botv.chat.send import send_private_msg, flush_outbox
        ws = FakeWS()
        asyncio.run(send_private_msg(123, [{"type": "text", "data": {"text": "a"}}], None))
        asyncio.run(send_private_msg(456, [{"type": "text", "data": {"text": "b"}}], None))
        sent = asyncio.run(flush_outbox(ws))
        self.assertEqual(sent, 2)
        self.assertEqual(len(cfg.pending_outbox), 0)
        self.assertEqual(len(ws.sent), 2)

    def test_flush_noop_when_empty(self):
        from botv.chat.send import flush_outbox
        self.assertEqual(asyncio.run(flush_outbox(FakeWS())), 0)


class TestHeartbeatWatchdog(unittest.TestCase):
    """F6：心跳连续失败要主动断开"""

    def test_closes_after_failures(self):
        from botv import heartbeat as hb

        class BadWS:
            closed = False

            def __init__(self):
                self.closed_count = 0

            async def ping(self):
                raise RuntimeError("dead")

            async def close(self):
                self.closed = True
                self.closed_count += 1

        ws = BadWS()
        orig = hb.HEARTBEAT_INTERVAL
        hb.HEARTBEAT_INTERVAL = 0.01
        try:
            async def run():
                task = asyncio.create_task(hb.heartbeat_monitor("T", ws))
                await asyncio.sleep(0.1)
                task.cancel()
            asyncio.run(run())
        finally:
            hb.HEARTBEAT_INTERVAL = orig
        self.assertTrue(ws.closed)
        self.assertGreaterEqual(ws.closed_count, 1)


class TestAntiAIStyle(unittest.TestCase):
    """v6-A23：反 AI 腔清单必须进 prompt"""

    def setUp(self):
        cfg.CODE_MODE = False

    def test_prompt_has_style_block(self):
        from botv.ai.prompt import get_system_prompt
        p = get_system_prompt()
        self.assertIn("别像 AI", p)
        self.assertIn("总而言之", p)
        self.assertIn("我理解你的感受", p)

    def test_code_mode_has_hint(self):
        from botv.ai.prompt import get_system_prompt
        cfg.CODE_MODE = True
        try:
            p = get_system_prompt()
        finally:
            cfg.CODE_MODE = False
        self.assertIn("总而言之", p)


class TestFewShot(unittest.TestCase):
    """v6-A22：示例对话要进 prompt，且不带 AI 腔"""

    def setUp(self):
        cfg.CODE_MODE = False

    def test_prompt_has_examples(self):
        from botv.ai.prompt import get_system_prompt
        p = get_system_prompt()
        self.assertIn("她说话的样子", p)
        self.assertIn("主人：", p)
        self.assertIn("奈绪：", p)

    def test_examples_show_optional_action(self):
        """示例里要有一条没有动作的，告诉模型动作可省"""
        from botv.ai.prompt import get_system_prompt
        p = get_system_prompt()
        block = p.split("【她说话的样子】")[1].split("回复必须")[0]
        lines = [l for l in block.split("\n") if l.startswith("奈绪：")]
        self.assertTrue(any("（" not in l for l in lines), "至少要有一条没动作的示例")


class TestBubbleDelay(unittest.TestCase):
    """v6-A12：气泡间隔随机，不是固定值"""

    def test_range(self):
        from botv.chat.send import bubble_delay, BUBBLE_DELAY_RANGE
        lo, hi = BUBBLE_DELAY_RANGE
        samples = [bubble_delay() for _ in range(200)]
        self.assertTrue(all(lo <= d <= hi for d in samples))
        self.assertGreater(len(set(samples)), 1, "应该是随机的")


class TestAtDetection(unittest.TestCase):
    """v6-E29：@ 判断"""

    def test_at_me(self):
        from botv.chat.inbound import is_at_me
        msg = [{"type": "text", "data": {"text": "hi"}},
               {"type": "at", "data": {"qq": "12345"}}]
        self.assertTrue(is_at_me(msg, 12345))
        self.assertFalse(is_at_me(msg, 999))
        self.assertFalse(is_at_me("plain text", 12345))

    def test_no_self_qq(self):
        from botv.chat.inbound import is_at_me
        msg = [{"type": "at", "data": {"qq": "12345"}}]
        self.assertFalse(is_at_me(msg, 0))


class _FakeRandom:
    def __init__(self, value):
        self.value = value

    def random(self):
        return self.value


class TestGroupGate(unittest.TestCase):
    """v6-E29：群聊节奏闸门"""

    def setUp(self):
        cfg.group_last_reply_ts.clear()
        cfg.group_msg_window.clear()

    def tearDown(self):
        cfg.group_last_reply_ts.clear()
        cfg.group_msg_window.clear()

    def test_addressed_passes(self):
        from botv.chat.handler import should_answer_group
        ok, why = should_answer_group(111, True)
        self.assertTrue(ok)
        self.assertEqual(why, "被@")

    def test_cooldown_blocks_unaddressed(self):
        from botv.chat.handler import should_answer_group, note_group_reply
        note_group_reply(111)
        ok, why = should_answer_group(111, False)
        self.assertFalse(ok)
        self.assertIn("冷却", why)

    def test_window_full_blocks_even_addressed(self):
        from botv.chat import handler as h
        for _ in range(h.GROUP_WINDOW_MAX):
            h.note_group_reply(222)
        ok, why = h.should_answer_group(222, True)
        self.assertFalse(ok)
        self.assertIn("60秒内", why)

    def test_probability_gate(self):
        from botv.chat import handler as h
        orig = h.random
        try:
            h.random = _FakeRandom(0.0)  # 一定命中
            ok, why = h.should_answer_group(333, False)
            self.assertTrue(ok)
            self.assertEqual(why, "随机接话")

            h.cfg.group_last_reply_ts.clear()
            h.random = _FakeRandom(0.99)  # 一定不中
            ok, why = h.should_answer_group(333, False)
            self.assertFalse(ok)
            self.assertIn("概率", why)
        finally:
            h.random = orig


class TestReplyTiming(unittest.TestCase):
    """v6-A1：延迟按时段浮动，且偏短"""

    class _R:
        def __init__(self, v):
            self.v = v

        def random(self):
            return self.v

    def test_bands(self):
        from datetime import datetime
        from botv.chat.timing import delay_range
        from botv.config import CST
        self.assertEqual(delay_range(datetime(2026, 1, 1, 2, tzinfo=CST)), (20, 180))
        self.assertEqual(delay_range(datetime(2026, 1, 1, 10, tzinfo=CST)), (5, 30))
        self.assertEqual(delay_range(datetime(2026, 1, 1, 20, tzinfo=CST)), (8, 60))
        self.assertEqual(delay_range(datetime(2026, 1, 1, 23, 30, tzinfo=CST)), (20, 120))

    def test_within_range(self):
        from datetime import datetime
        from botv.chat.timing import reply_delay
        from botv.config import CST
        now = datetime(2026, 1, 1, 10, tzinfo=CST)
        for v in (0.0, 0.5, 0.999):
            d = reply_delay(now, self._R(v))
            self.assertGreaterEqual(d, 5)
            self.assertLessEqual(d, 30)

    def test_biased_short(self):
        from datetime import datetime
        from botv.chat.timing import reply_delay
        from botv.config import CST
        now = datetime(2026, 1, 1, 10, tzinfo=CST)
        vals = [reply_delay(now, self._R(i / 100)) for i in range(100)]
        mean = sum(vals) / len(vals)
        self.assertLess(mean, 17.5, f"应偏短，实际均值 {mean:.1f}")


class TestConcurrency(unittest.TestCase):
    """v6-E26：按对象分片锁 + 模型调用上限"""

    def setUp(self):
        cfg.target_locks.clear()

    def tearDown(self):
        cfg.target_locks.clear()

    def test_same_target_serialized(self):
        from botv.core.locks import get_target_lock
        st = {"active": 0, "peak": 0}

        async def run():
            async def worker():
                async with get_target_lock("x"):
                    st["active"] += 1
                    st["peak"] = max(st["peak"], st["active"])
                    await asyncio.sleep(0.01)
                    st["active"] -= 1
            await asyncio.gather(worker(), worker(), worker())

        asyncio.run(run())
        self.assertEqual(st["peak"], 1, "同一个人必须串行")

    def test_different_targets_parallel(self):
        from botv.core.locks import get_target_lock
        st = {"active": 0, "peak": 0}

        async def run():
            async def worker(tid):
                async with get_target_lock(tid):
                    st["active"] += 1
                    st["peak"] = max(st["peak"], st["active"])
                    await asyncio.sleep(0.02)
                    st["active"] -= 1
            await asyncio.gather(worker("a"), worker("b"), worker("c"))

        asyncio.run(run())
        self.assertEqual(st["peak"], 3, "三个人应该能并行")

    def test_cleanup_idle_locks(self):
        from botv.core import locks
        locks.get_target_lock("old")
        locks._last_used["old"] -= 700
        removed = locks.cleanup_idle_locks()
        self.assertGreaterEqual(removed, 1)
        self.assertNotIn("old", cfg.target_locks)

    def test_model_semaphore_limit(self):
        from botv.core import locks
        locks._model_sem = None  # 每个用例用新的信号量，避免跨事件循环
        st = {"active": 0, "peak": 0}

        async def run():
            sem = locks.model_semaphore()

            async def call():
                async with sem:
                    st["active"] += 1
                    st["peak"] = max(st["peak"], st["active"])
                    await asyncio.sleep(0.01)
                    st["active"] -= 1
            await asyncio.gather(*[call() for _ in range(12)])

        asyncio.run(run())
        self.assertEqual(st["peak"], locks.MAX_CONCURRENT_MODEL_CALLS)


class TestTone(unittest.TestCase):
    """v6-A20：按时段给语气提示"""

    def test_bands(self):
        from datetime import datetime
        from botv.chat.timing import tone_hint
        from botv.config import CST
        self.assertIn("困", tone_hint(datetime(2026, 1, 1, 2, tzinfo=CST)))
        self.assertIn("刚醒", tone_hint(datetime(2026, 1, 1, 7, tzinfo=CST)))
        self.assertIn("精神", tone_hint(datetime(2026, 1, 1, 12, tzinfo=CST)))
        self.assertIn("放松", tone_hint(datetime(2026, 1, 1, 20, tzinfo=CST)))

    def test_prompt_has_tone(self):
        import botv.ai.client as client
        import botv.memory as mem
        from botv.core import locks
        captured = {}

        async def fake_ds(msgs, max_tokens=None, target_id=None):
            captured["sys"] = msgs[0]["content"]
            return "好"

        orig_ds, orig_ev = client.call_deepseek, mem.load_events_from_db
        client.call_deepseek = fake_ds
        mem.load_events_from_db = lambda *a, **k: []
        locks._model_sem = None
        try:
            asyncio.run(client.get_character_reply("hi", "1"))
        finally:
            client.call_deepseek = orig_ds
            mem.load_events_from_db = orig_ev
        self.assertIn("你现在的状态", captured["sys"])
        self.assertNotIn("{tone}", captured["sys"])


if __name__ == "__main__":
    unittest.main()
